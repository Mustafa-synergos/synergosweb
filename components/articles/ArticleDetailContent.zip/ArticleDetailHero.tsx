'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useMemo } from 'react';
import ArticleCard from '@/components/articles/ArticleCard';
import InteractiveDots from '@/components/home/InteractiveDots';
import type { ArticleData } from '@/types/article';

type Props = {
  article: ArticleData;
  related: ArticleData[];
};

/* =============================================================
   Date formatting — adjust to match whatever helper you already
   use elsewhere in the app (kept local here so this file is
   drop-in even if you don't have one yet).
============================================================= */
function formatDate(dateString: string) {
  return new Date(dateString).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

/* =============================================================
   1. CONTENT PARSER (no external dependency)
============================================================= */

type ContentBlock =
  | { type: 'heading'; html: string }
  | { type: 'paragraph'; html: string }
  | { type: 'image'; src: string; alt: string }
  | { type: 'pair'; html: string; src: string; alt: string; reverse: boolean };

type RawNode = { tag: string; inner: string; src?: string; alt?: string };

function extractTopLevelNodes(rawHtml: string): RawNode[] {
  if (!rawHtml) return [];

  const nodes: RawNode[] = [];
  const regex = /<(h[1-3])[^>]*>([\s\S]*?)<\/\1>|<p[^>]*>([\s\S]*?)<\/p>|<img[^>]*>/gi;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(rawHtml)) !== null) {
    const full = match[0];

    if (/^<h[1-3]/i.test(full)) {
      nodes.push({ tag: 'heading', inner: match[2] ?? '' });
      continue;
    }

    if (/^<p/i.test(full)) {
      const innerContent = match[3] ?? '';
      const imgMatch = innerContent.match(/<img[^>]*>/i);
      const textOnly = innerContent.replace(/<img[^>]*>/gi, '').replace(/<[^>]+>/g, '').trim();

      if (imgMatch && !textOnly) {
        const src = imgMatch[0].match(/src=["']([^"']+)["']/i)?.[1] ?? '';
        const alt = imgMatch[0].match(/alt=["']([^"']*)["']/i)?.[1] ?? '';
        nodes.push({ tag: 'image', inner: '', src, alt });
      } else {
        nodes.push({ tag: 'paragraph', inner: innerContent });
      }
      continue;
    }

    if (/^<img/i.test(full)) {
      const src = full.match(/src=["']([^"']+)["']/i)?.[1] ?? '';
      const alt = full.match(/alt=["']([^"']*)["']/i)?.[1] ?? '';
      nodes.push({ tag: 'image', inner: '', src, alt });
    }
  }

  return nodes;
}

function parseArticleContent(rawHtml: string): ContentBlock[] {
  const nodes = extractTopLevelNodes(rawHtml);
  const blocks: ContentBlock[] = [];
  let imageIndex = 0;

  for (let i = 0; i < nodes.length; i++) {
    const node = nodes[i];

    if (node.tag === 'heading') {
      blocks.push({ type: 'heading', html: node.inner });
      continue;
    }

    if (node.tag === 'image') {
      imageIndex++;
      blocks.push({ type: 'image', src: node.src ?? '', alt: node.alt ?? '' });
      continue;
    }

    if (node.tag === 'paragraph') {
      const next = nodes[i + 1];

      if (next && next.tag === 'image') {
        const reverse = imageIndex % 2 === 1;
        imageIndex++;
        blocks.push({
          type: 'pair',
          html: node.inner,
          src: next.src ?? '',
          alt: next.alt ?? '',
          reverse,
        });
        i++;
        continue;
      }

      blocks.push({ type: 'paragraph', html: node.inner });
    }
  }

  return blocks;
}

/* =============================================================
   2. SHARE BAR
============================================================= */

function ShareBar({ title, slug }: { title: string; slug: string }) {
  if (typeof window === 'undefined') return null;
  const url = `${window.location.origin}/resources/article/${slug}`;
  const encoded = encodeURIComponent(url);
  const text = encodeURIComponent(title);

  return (
    <div className="flex items-center gap-4">
      <span className="font-clother text-[13px] font-semibold uppercase tracking-[0.18em] text-white/60">
        Share:
      </span>
      <div className="flex items-center gap-3">
        <a href={`https://www.facebook.com/sharer/sharer.php?u=${encoded}`} target="_blank" rel="noopener noreferrer" className="flex h-9 w-9 items-center justify-center rounded-full bg-white transition-opacity hover:opacity-80">
          <img src="/images/blog/facebook.svg" alt="Facebook" className="h-4 w-4" />
        </a>
        <a href={`https://www.linkedin.com/shareArticle?mini=true&url=${encoded}&title=${text}`} target="_blank" rel="noopener noreferrer" className="flex h-9 w-9 items-center justify-center rounded-full bg-white transition-opacity hover:opacity-80">
          <img src="/images/blog/linkedin.svg" alt="LinkedIn" className="h-4 w-4" />
        </a>
        <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer" className="flex h-9 w-9 items-center justify-center rounded-full bg-white transition-opacity hover:opacity-80">
          <img src="/images/blog/instagram.svg" alt="Instagram" className="h-4 w-4" />
        </a>
        <a href={`https://x.com/intent/tweet?url=${encoded}&text=${text}`} target="_blank" rel="noopener noreferrer" className="flex h-9 w-9 items-center justify-center rounded-full bg-white transition-opacity hover:opacity-80">
          <img src="/images/blog/x.svg" alt="X" className="h-4 w-4" />
        </a>
      </div>
    </div>
  );
}

/* =============================================================
   3. BODY RENDERER
============================================================= */

function ArticleBody({ html }: { html: string }) {
  const blocks = useMemo(() => parseArticleContent(html), [html]);

  return (
    <div className="w-full">
      {blocks.map((block, idx) => {
        if (block.type === 'heading') {
          return (
            <h2
              key={idx}
              className="mt-16 mb-6 font-clother text-[26px] font-semibold leading-snug text-[#FF4040] first:mt-0"
              dangerouslySetInnerHTML={{ __html: block.html }}
            />
          );
        }

        if (block.type === 'paragraph') {
          return (
            <div
              key={idx}
              className="max-w-[1150px] text-[17px] leading-[2] text-[#CFCFCF] [&_p]:mb-6 [&_p:last-child]:mb-0"
              dangerouslySetInnerHTML={{ __html: block.html }}
            />
          );
        }

        if (block.type === 'image') {
          return (
            <div key={idx} className="relative my-10 h-[380px] w-full overflow-hidden">
              <Image src={block.src} alt={block.alt} fill className="object-cover" unoptimized={block.src.startsWith('http')} />
            </div>
          );
        }

        return (
          <div
            key={idx}
            className={`my-10 grid grid-cols-1 items-center gap-10 lg:grid-cols-2 ${
              block.reverse ? 'lg:[&>*:first-child]:order-2' : ''
            }`}
          >
            <div
              className="text-[17px] leading-[2] text-[#CFCFCF] [&_p]:mb-6 [&_p:last-child]:mb-0"
              dangerouslySetInnerHTML={{ __html: block.html }}
            />
            <div className="relative h-[300px] w-full overflow-hidden">
              <Image src={block.src} alt={block.alt} fill className="object-cover" unoptimized={block.src.startsWith('http')} />
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* =============================================================
   4. PAGE
============================================================= */

// export default function ArticleDetailContent({ article, related }: Props) {
export default function ArticleDetailContent({
  article,
  related = [],
}: Props) {
  const imageUrl = article.FeaturedImage?.url;

  return (
    <section className="relative overflow-hidden bg-[#111111] px-6 py-16 sm:px-8 lg:px-0">
      <div className="pointer-events-none">
        <InteractiveDots variant="dark" />
      </div>

      <div className="relative mx-auto max-w-[1400px] px-4 lg:px-8">
        {/* HERO — plain layout, no card/border, matches reference exactly */}
        <article>
          <div className="grid grid-cols-1 items-center gap-16 lg:grid-cols-[480px_1fr]">
            {/* LEFT */}
            <div>
              {article.Category && (
                <span className="inline-flex rounded-full border border-[#2B2B2B] px-5 py-2 text-[13px] font-medium text-[#FF4040]">
                  {article.Category}
                </span>
              )}

              <h1 className="mt-8 font-clother text-[52px] leading-[60px] font-semibold text-white">
                {article.Title}
              </h1>

              <div className="mt-10 flex flex-wrap items-center gap-8 text-[15px] text-white/60">
                {article.publishedAt && (
                  <div className="flex items-center gap-2">
                    <img src="/images/blog/calendar.svg" alt="" className="h-5 w-5" />
                    {formatDate(article.publishedAt)}
                  </div>
                )}
                {article.ReadTime && (
                  <div className="flex items-center gap-2">
                    <img src="/images/blog/time.png" alt="" className="h-5 w-5" />
                    {article.ReadTime}
                  </div>
                )}
              </div>

              <div className="mt-14">
                <ShareBar title={article.Title} slug={article.Slug} />
              </div>
            </div>

            {/* RIGHT — plain image, no border/radius, fixed height like reference */}
            <div>
              {imageUrl ? (
                <div className="relative h-[520px] w-full overflow-hidden">
                  <Image
                    src={imageUrl}
                    alt={article.FeaturedImage?.alternativeText ?? article.Title}
                    fill
                    className="object-cover"
                    unoptimized={imageUrl.startsWith('http')}
                    priority
                  />
                </div>
              ) : (
                <div className="h-[520px] w-full bg-white/[0.04]" />
              )}
            </div>
          </div>

          {/* CONTENT — full width, alternating layout */}
          <div className="mt-28 w-full">
            {article.Content ? (
              <ArticleBody html={article.Content} />
            ) : (
              <p className="text-white/30">No content available.</p>
            )}
          </div>

          {/* BACK */}
          {/* <div className="mt-20 border-t border-white/10 pt-10">
            <Link
              href="/resources/articles"
              className="inline-flex items-center gap-3 text-[14px] text-white/60 transition hover:text-white"
            >
              <img src="/images/blog/arrow-2.svg" className="h-3 w-3 rotate-180" alt="" />
              Back to all articles
            </Link>
          </div> */}
        </article>

        {/* RELATED — 2 columns, matches reference */}
        <section className="mt-36">
          {/* <h2 className="mb-10 font-clother text-[34px] font-semibold text-white">
            Other Articles
          </h2> */}

          <div className="grid gap-8 lg:grid-cols-2">
           {(related ?? []).length > 0 ? (
  (related ?? []).map((item, index) => (
                <ArticleCard
                  key={item.documentId ?? item.Slug}
                  article={item}
                  index={index}
                  hideExcerpt
                />
              ))
            ) : (
              <p className="text-white/30">No related articles.</p>
            )}
          </div>
        </section>
      </div>
    </section>
  );
}